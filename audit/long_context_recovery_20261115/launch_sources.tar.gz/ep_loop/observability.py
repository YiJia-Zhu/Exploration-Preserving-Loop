"""Rank-local stage events, console capture and throttled progress bars.

No Torch import, CUDA synchronization, random-stream consumption, token-level
file writes or model inspection. Timings are host wall time, not GPU profiles.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
import itertools
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import uuid
import weakref
from zoneinfo import ZoneInfo

from tqdm.auto import tqdm


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def env_bool(name, default=True):
    value = os.environ.get(name, str(int(default))).lower()
    if value not in {"0", "1", "true", "false"}:
        raise ValueError(f"{name} must be 0/1 or false/true")
    return value in {"1", "true"}


@contextmanager
def model_progress(enabled):
    """Also suppress Transformers checkpoint bars on non-display ranks."""
    from transformers.utils import logging as hf_logging
    previous = hf_logging.is_progress_bar_enabled()
    if not enabled:
        hf_logging.disable_progress_bar()
    try:
        yield
    finally:
        if previous:
            hf_logging.enable_progress_bar()
        else:
            hf_logging.disable_progress_bar()


class Tee:
    def __init__(self, stream, log):
        self.stream, self.log = stream, log

    def write(self, text):
        self.log.write(text)
        return self.stream.write(text)

    def flush(self):
        self.log.flush()
        self.stream.flush()

    def __getattr__(self, key):
        return getattr(self.stream, key)


class RunLogger:
    def __init__(self, events_path, console_path, name, rank=0):
        self.events_path, self.console_path = Path(events_path), Path(console_path)
        self.name, self.rank = name, rank
        self.session_id = uuid.uuid4().hex
        self.started_at = utc_now()
        self.clock = time.perf_counter()
        self.timezone = ZoneInfo(os.environ.get("EP_LOOP_LOG_TIMEZONE", "Asia/Shanghai"))
        self.show_progress = env_bool("EP_LOOP_PROGRESS") and rank == 0
        self.show_tokens = self.show_progress and env_bool("EP_LOOP_TOKEN_PROGRESS")
        self.mininterval = float(os.environ.get("EP_LOOP_PROGRESS_MIN_INTERVAL", "1.0"))
        if not 0 < self.mininterval < float("inf"):
            raise ValueError("EP_LOOP_PROGRESS_MIN_INTERVAL must be finite and positive")
        self.stack, self.bars = [], weakref.WeakSet()
        self.counter = itertools.count(1)

    def __enter__(self):
        self.events_path.parent.mkdir(parents=True, exist_ok=True)
        self.console_path.parent.mkdir(parents=True, exist_ok=True)
        self.events = self.events_path.open("a", buffering=1)
        self.console = self.console_path.open("a", buffering=1)
        self.stdout, self.stderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = Tee(self.stdout, self.console), Tee(self.stderr, self.console)
        self.tee_stdout, self.tee_stderr = sys.stdout, sys.stderr
        for handler in self.stream_handlers():
            if handler.stream is self.stdout:
                handler.setStream(self.tee_stdout)
            elif handler.stream is self.stderr:
                handler.setStream(self.tee_stderr)
        self.event("run_start", echo=True, progress=self.show_progress, token_progress=self.show_tokens)
        return self

    @staticmethod
    def stream_handlers():
        loggers = [logging.getLogger(), *logging.Logger.manager.loggerDict.values()]
        seen = set()
        for logger in loggers:
            if isinstance(logger, logging.Logger):
                for handler in logger.handlers:
                    if isinstance(handler, logging.StreamHandler) and id(handler) not in seen:
                        seen.add(id(handler))
                        stream = getattr(type(handler), "stream", None)
                        # Some libraries expose a read-only stream property
                        # that follows sys.stderr dynamically. It needs no swap.
                        if isinstance(stream, property) and stream.fset is None:
                            continue
                        yield handler

    def event(self, event, echo=False, **fields):
        now = datetime.now(timezone.utc)
        row = dict(event=event, timestamp=now.isoformat(timespec="milliseconds"),
            local_time=now.astimezone(self.timezone).isoformat(timespec="milliseconds"),
            session_id=self.session_id, name=self.name, rank=self.rank, pid=os.getpid(),
            parent_session_id=os.environ.get("EP_LOOP_PARENT_SESSION_ID"),
            elapsed_seconds=time.perf_counter()-self.clock, **fields)
        self.events.write(json.dumps(row, ensure_ascii=False)+"\n")
        if echo and self.rank == 0:
            label = fields.get("stage", self.name)
            suffix = f" ({fields['seconds']:.3f}s)" if "seconds" in fields else ""
            tqdm.write(f"[{row['local_time']}] {event}: {label}{suffix}", file=sys.stderr)
        return row

    def start(self, stage, echo=False, **fields):
        span = dict(stage=stage, stage_id=next(self.counter),
                    parent_stage_id=self.stack[-1]["stage_id"] if self.stack else None,
                    started_at=utc_now(), fields=fields, echo=echo, clock=time.perf_counter())
        self.stack.append(span)
        self.event("stage_start", echo=echo, **{k:v for k,v in span.items() if k not in {"clock", "echo", "fields"}}, **fields)
        return span

    def finish(self, span, status="completed", **fields):
        if not self.stack or self.stack[-1] is not span:
            raise RuntimeError("Stage events must close in nesting order")
        self.stack.pop()
        return self.event("stage_end", echo=span["echo"],
            stage=span["stage"], stage_id=span["stage_id"], parent_stage_id=span["parent_stage_id"],
            started_at=span["started_at"], finished_at=utc_now(),
            seconds=time.perf_counter()-span["clock"], status=status, **(span["fields"] | fields))

    @contextmanager
    def stage(self, stage, echo=False, **fields):
        span = self.start(stage, echo, **fields)
        result = {}
        try:
            yield result
        except BaseException as exc:
            while self.stack and self.stack[-1] is not span:
                self.finish(self.stack[-1], "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed",
                            error_type=type(exc).__name__, error=str(exc))
            self.finish(span, "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed",
                        **(result | dict(error_type=type(exc).__name__, error=str(exc))))
            raise
        else:
            self.finish(span, **result)

    def progress(self, iterable=None, *, tokens=False, **kwargs):
        bar = tqdm(iterable, disable=not (self.show_tokens if tokens else self.show_progress),
                   mininterval=self.mininterval, dynamic_ncols=True, file=sys.stderr, **kwargs)
        self.bars.add(bar)
        return bar

    def metadata(self):
        return dict(session_id=self.session_id, started_at=self.started_at,
            events=str(self.events_path.resolve()), console=str(self.console_path.resolve()),
            timezone=str(self.timezone), progress=self.show_progress, token_progress=self.show_tokens,
            progress_min_interval=self.mininterval, timing="host wall time; no additional CUDA synchronization")

    def __exit__(self, kind, exc, tb):
        success = exc is None or isinstance(exc, SystemExit) and exc.code in (None, 0)
        status = "completed" if success else "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed"
        try:
            for bar in sorted(self.bars, key=lambda bar:abs(bar.pos), reverse=True):
                bar.close()
            while self.stack:
                self.finish(self.stack[-1], status, error=str(exc) if exc else "unclosed stage")
            fields = dict(status=status, started_at=self.started_at, finished_at=utc_now(),
                          seconds=time.perf_counter()-self.clock)
            if not success:
                fields.update(error_type=kind.__name__, error=str(exc),
                              traceback="".join(traceback.format_exception(kind, exc, tb)))
                self.console.write(fields["traceback"])
            self.event("run_end", echo=True, **fields)
        finally:
            try:
                for handler in self.stream_handlers():
                    if handler.stream is self.tee_stdout:
                        handler.setStream(self.stdout)
                    elif handler.stream is self.tee_stderr:
                        handler.setStream(self.stderr)
            finally:
                sys.stdout, sys.stderr = self.stdout, self.stderr
                self.events.close()
                self.console.close()


def run_command(cmd, env, cwd, logger, label, log_path):
    """Stream child stdout/stderr to the terminal and a persistent raw log."""
    import codecs
    path = Path(log_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with logger.stage("subprocess", echo=True, label=label, command=list(map(str, cmd)),
                      log_path=str(path), cuda_visible_devices=env.get("CUDA_VISIBLE_DEVICES")) as result:
        with path.open("ab") as log:
            child_env = {**env, "EP_LOOP_PARENT_SESSION_ID": logger.session_id}
            with subprocess.Popen(cmd, env=child_env, cwd=cwd, stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT, bufsize=0) as process:
                decoder = codecs.getincrementaldecoder("utf-8")("replace")
                try:
                    while chunk := process.stdout.read(65536):
                        log.write(chunk)
                        log.flush()
                        sys.stdout.write(decoder.decode(chunk))
                        sys.stdout.flush()
                    sys.stdout.write(decoder.decode(b"", final=True))
                    code = process.wait()
                except BaseException:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    raise
        result["returncode"] = code
        if code:
            raise subprocess.CalledProcessError(code, cmd)
