"""Worker extension loaded through vLLM's public extension/RPC interface."""
from pathlib import Path
from datetime import datetime,timezone
import json
import os
import sys
import time
from zoneinfo import ZoneInfo
import torch


class OuroWorkerExtension:
    def ep_start_trace(self):
        model=self.get_model()
        self._ep_depth_rows=[]
        self._ep_trace_counts={}
        self._ep_progress_clock=time.monotonic()
        def capture(depths):
            request_ids=list(self.model_runner.input_batch.req_ids)
            if len(request_ids)!=depths.shape[0]:
                raise RuntimeError('Depth diagnostics require one sampled row per request; prompt logprobs/chunked prefill disabled')
            self._ep_depth_rows.append((request_ids,depths.detach().clone()))
            for request_id in request_ids:
                self._ep_trace_counts[request_id]=self._ep_trace_counts.get(request_id,0)+1
            now=time.monotonic()
            if now-self._ep_progress_clock>=10:
                print(json.dumps(dict(event='vllm_generation_progress',
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    local_time=datetime.now(timezone.utc).astimezone(ZoneInfo(os.environ.get('EP_LOOP_LOG_TIMEZONE','Asia/Shanghai'))).isoformat(),
                    generated_tokens=self._ep_trace_counts)),file=sys.stderr,flush=True)
                self._ep_progress_clock=now
        model._depth_callback=capture
        return True

    def ep_finish_trace(self):
        self.get_model()._depth_callback=None
        rows=getattr(self,'_ep_depth_rows',[])
        result={}
        if rows:
            flat=torch.cat([values for _,values in rows]).float().cpu().tolist()
            offset=0
            for request_ids,values in rows:
                for index,request_id in enumerate(request_ids):
                    result.setdefault(request_id,dict(depths=[],gate_logits=[]))
                    result[request_id]['depths'].append(int(flat[offset+index][0]))
                    result[request_id]['gate_logits'].append(flat[offset+index][1:])
                offset+=len(request_ids)
        self._ep_depth_rows=[]
        return result

    def ep_load_weights(self, filename, version):
        """Called while idle, after wake-up and before any next-update request."""
        from safetensors import safe_open
        if int(version)<=getattr(self,'_ep_weight_version',-1):
            raise ValueError('Student weight versions must increase monotonically')
        with safe_open(str(Path(filename)),framework='pt',device='cpu') as source:
            names=list(source.keys())
            loaded=self.get_model().load_weights((name,source.get_tensor(name)) for name in names)
        self._ep_weight_version=int(version)
        return dict(weight_version=int(version),source_tensors=len(names),loaded_parameters=len(loaded))

    def ep_health(self):
        return dict(weight_version=getattr(self,'_ep_weight_version',0),
                    model_type=type(self.get_model()).__name__,
                    configured_recurrent_steps=int(self.get_model().model.total_ut_steps))
