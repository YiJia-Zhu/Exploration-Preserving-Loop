# 三条研究路线与第一轮vLLM消融

统一入口为`scripts/run_three_route_ablation.sh`，新入口默认`ROUTE=hybrid`。历史`run_ablation.sh`与`configs/default.json`的HF学生动态默认保持，用于复现既有运行；新HF研究线显式使用`hf_adaptive`，其教师也能真实提前停止。三条研究线均使用完整词表JS与reverse KL，词表top-20近似单独保留为可选实验。

| ROUTE | 教师实际执行 | 训练时的学生回答 | 阶段监督 | 部署评测 |
|---|---|---|---|---|
| `hf` | 原生CDF达到阈值即停止，必要时精确补齐历史KV | HF逐token真实动态停止 | 教师实际终点前全部JS超阈值边界＋终点 | HF逐token真实动态停止 |
| `vllm` | 固定K轮，监督终点固定K | vLLM固定N轮 | endpoint、uniform_n、top_n三组 | vLLM固定N轮 |
| `hybrid` | 固定K轮，再按原生CDF选择逻辑终点 | HF逐token真实动态停止 | 逻辑终点前全部JS超阈值边界＋终点 | 同一checkpoint，用vLLM分别真正执行多个固定N |

这里的轮次为共享Transformer模块的循环次数。三线首版均使用Ouro-1.4B-Thinking，教师为冻结的初始权重；学生全参数训练。不合并师生前向，不引入单前向当前模型自蒸馏。HF／交叉线保留原停止BCE，只监督到各位置的目标阶段数；本次没有增加退出后的额外深度损失。

## 第一轮先跑vLLM线：K=4，N=2

| 组别 | 学生第1轮目标 | 学生第2轮目标 | 目的 |
|---|---|---|---|
| `endpoint` | 无直接阶段KL | 教师第4轮 | LoopOPD式终点监督，当前按消融对照记录 |
| `uniform_n` | 教师第2轮 | 教师第4轮 | 固定数量、均匀阶段目标 |
| `top_n` | 最大相邻JS边界之前的教师轮次b | 教师第4轮 | 固定数量、按分布变化选阶段 |

`top_n`对每个位置选N−1个最大的相邻JS边界，按原时间顺序排序，再追加教师终点K，总共恰好N个监督目标。不会再用JS>0.05过滤，不采用旧`n_t<=N`时只学终点的回退；JS为零仍确定选择，平局选较早边界。N=1仅监督终点；N=K逐轮对应。`uniform_n`同样恰好N个目标，目标轮次为ceil(jK/N)。

固定学生不训练退出BCE，停止损失为0。多阶段KL按每位置有效目标数平均，再平均回答token与回答；终点对照仅在学生最后一轮监督。学生生成、可微回放和部署都实际执行N轮，不能仍算K轮再读第N轮。vLLM actor按N建引擎，输出及只读health查询均可核验实际轮数。

首轮参数：

- 模型revision保持`3aaa2224253a92ca45cf2e3d427c360e1ef9c93d`，教师冻结，K=4，学生N=2。
- DAPO按同一seed42划分训练256题、开发评测64题，互斥，不改prompt；教师题目与学生回答均不按正确性过滤。
- 当前10小时限时首轮每组10次更新；每次4题×4回答=全局16，GPU 2、3各8条；每次更新前同步当前学生权重，确认版本后由vLLM生成该批回答，再HF回放与梯度累积，执行一次AdamW。通用入口的UPDATES默认仍为20，本轮启动显式覆盖为10。
- LR1e-6、WD0.01、betas=(0.9,0.999)、eps=1e-8、warmup0、无梯度裁剪；FP32主参数、BF16计算、gradient checkpointing、readout chunk128。
- prompt最多1024，训练与评测回答上限均16384；训练T=1/top-p=1，评测T=1/top-p=0.7，每题1次。
- 每卡最多2个vLLM活动请求，模型与KV按实际N执行。固定N不使用学生gate决定读出。
- 三组顺序运行，每组从原始权重初始化，数据与抽样种子协议一致。本轮EVAL_INITIAL=0，跳过未训练模型的额外K／N评测；每组仅评最终10步checkpoint，使用相同64道DAPO开发题。组间生成文本可能因策略变化而不同，不要求训练采样轨迹相同。
- 每次更新保存完整恢复点（含optimizer和各rank RNG），滚动保留最近1份，永久保留最终快照。初始方案KEEP=2并保留10／20快照需约171 GiB；本轮最终评测协议使用KEEP=1／仅保留最终定期点，预检估算约91 GiB。没有关闭optimizer保存或删除既有实验。
- MAX_RUNTIME_HOURS=10限制整个panel的墙钟时间，包括配置准备、编译、训练、保存和评测。独立watchdog在截止前15秒开始停止本次任务进程树；各更新完整保存后原子写入checkpoint.complete.json，可区分中断中的目录与完整恢复点。时间不足时panel可能只完成部分组别，不自动延长或降低生成上限。

```bash
# 只读查看全部三组，GPU与超参数均在脚本开头。
ROUTE=vllm GPUS=2,3 bash scripts/run_three_route_ablation.sh --dry-run

# 本轮10小时限时配置，顺序运行三组。
ROUTE=vllm GPUS=2,3 UPDATES=10 EVAL_UPDATES=10 SAVE_EVERY_UPDATES=10 \
  EVAL_INITIAL=0 MAX_RUNTIME_HOURS=10 bash scripts/run_three_route_ablation.sh

# 只运行核心top-N组。
ROUTE=vllm ABLATION_GROUPS=top_n bash scripts/run_three_route_ablation.sh

# 其余两条线。
ROUTE=hf bash scripts/run_three_route_ablation.sh --dry-run
ROUTE=hybrid EVAL_STUDENT_LOOPS=1,2,3,4 bash scripts/run_three_route_ablation.sh --dry-run
```

`OUTPUT_ROOT`可指定另一个有空间的目录；空间检查针对实际输出所在文件系统。`--check`只读检查，`--prepare-only`只生成数据分区和解析配置，不推理或训练。已有输出不会覆盖。

## HF与交叉线实现边界

HF教师原生CDF在线累积遵循官方dtype和stick-breaking顺序；仅配置的第K轮接收全部剩余概率，不会把“目前最后访问轮次”误当终点。已知学生文本按prompt预填充后逐位置流式标注，用精确深度KV和状态缓存补齐缺失历史。未访问深度只为标签张量补形状，不计算骨干；这些位置被出口掩码排除，不参与JS／KL。教师真实token-loops包含历史补算并单列`teacher_backfill_token_loops`。该HF机制线可能因串行标签计算而慢，不能由出口变浅直接宣称吞吐改善；0.9阈值仍是开发设置，不保证产生混合深度。

交叉线训练仍使用原HF动态rollout与可微回放。部署读取同一checkpoint，按N=1、2、3、4分别创建固定N的vLLM计算图，直接用第N轮分布，不调用停止头选择输出。不为每个N重训。训练可变阶段目标与固定N部署存在差异，须报告完整预算曲线，在开发集选择预算后再固定协议测试。

vLLM的sleep/wake内存池与HF的`expandable_segments:True`不兼容；actor子进程隔离该环境变量，HF训练进程仍保留原allocator设置，不修改site-packages或模型文件。

## 验证与结果边界

检查见`audit/three_routes_20261117/`：104项测试通过，覆盖固定N选段、教师真实CDF停算与历史补算、教师梯度隔离、固定学生无BCE、N而非K传入actor、交叉线同checkpoint多预算评测、限时清理及完整checkpoint标记；三线均完成CPU两步训练与CPU配置准备。真实Ouro引擎检查N=1／2／4的实际配置与生成深度；真实双卡DDP完成两次短更新，验证固定N=2、教师K=4、完整词表和停止损失为0。短诊断不提供任务效果结论；完整实验结果以新运行目录的metrics和评测summary为准。
