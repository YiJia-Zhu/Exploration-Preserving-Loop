"""Research-route semantics: exact budgets, real CDF exits and hybrid deployment."""
from contextlib import nullcontext
import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch,MagicMock

import torch
from ep_loop.config import load_config, validate_config
from ep_loop.data import ByteTokenizer
from ep_loop.objective import DistillationObjective
from ep_loop.ouro import tiny_ouro
from ep_loop.selection import make_stage_plan_from_js

ROOT=Path(__file__).resolve().parents[1]


class ThreeRouteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        torch.manual_seed(42)
        cls.template=tiny_ouro(ROOT/'models/Ouro-1.4B-Thinking')

    def backend(self):
        return type(self.template)(copy.deepcopy(self.template.model),'none')

    def test_fixed_top_n_keeps_exactly_n_and_endpoint_even_at_zero_js(self):
        js=torch.zeros(3,5)
        for n in [1,2,3,4]:
            plan=make_stage_plan_from_js(js,torch.full((5,),4),n,'top_n',999)
            self.assertEqual(plan.counts.tolist(),[n]*5)
            self.assertEqual(plan.teacher_depths[-1].tolist(),[4]*5)
            self.assertEqual(plan.teacher_depths[:,0].tolist(),list(range(1,n))+[4])
            torch.testing.assert_close(plan.weights.sum(0),torch.ones(5))

    def test_fixed_top_n_uses_rank_not_threshold_and_keeps_temporal_order(self):
        js=torch.tensor([[.03],[.01],[.02]])
        plan=make_stage_plan_from_js(js,torch.tensor([4]),3,'top_n',.9)
        self.assertEqual(plan.teacher_depths[:,0].tolist(),[1,3,4])
        uniform=make_stage_plan_from_js(js,torch.tensor([4]),2,'uniform_n')
        self.assertEqual(uniform.teacher_depths[:,0].tolist(),[2,4])
        with self.assertRaisesRegex(ValueError,'fixed teacher endpoint'):
            make_stage_plan_from_js(js,torch.tensor([3]),2,'top_n')

    def test_native_cdf_stops_after_two_loops_not_after_first_partial_trace(self):
        backend=self.backend();backend.model.eval()
        ids=torch.tensor([[1,20,30]])
        gate=backend.model.model.early_exit_gate
        calls=[]
        hook=backend.model.model.layers[0].register_forward_hook(lambda *args:calls.append(1))
        try:
            with torch.no_grad(),patch.object(gate,'forward',side_effect=lambda hidden:hidden.new_zeros((*hidden.shape[:2],1))):
                trace=backend.trace(ids,4,use_cache=True,endpoint='native_adaptive',exit_threshold=.7)
        finally:hook.remove()
        self.assertEqual(trace.exits[0,-1].item(),2)
        self.assertEqual(len(calls),2)
        self.assertEqual(trace.executed_token_loops,6)

    def test_adaptive_teacher_labels_match_full_prefix_with_late_backfill(self):
        backend=self.backend();backend.model.eval()
        ids=torch.tensor([[1,20,30,40,50,60]])
        schedule=[1,4,2,3];position=[0];depth=[0]
        def gate(hidden):
            depth[0]+=1
            stop=depth[0]>=schedule[position[0]]
            if stop:position[0]+=1;depth[0]=0
            return hidden.new_full((*hidden.shape[:2],1),100. if stop else -100.)
        with torch.no_grad():
            with patch.object(backend.model.model.early_exit_gate,'forward',side_effect=gate):
                adaptive=backend.response_trace(ids,4,2,'native_adaptive',.7)
            full=backend.response_trace(ids,4,2)
        self.assertEqual(adaptive.exits.tolist(),schedule)
        self.assertEqual(adaptive.executed_token_loops,22)
        self.assertEqual(adaptive.backfill_token_loops,10)
        for token,visited in enumerate(schedule):
            for loop in range(visited):
                torch.testing.assert_close(adaptive.states[loop][token],full.states[loop][token],rtol=3e-4,atol=3e-6)

    def test_true_adaptive_teacher_keeps_only_one_stage_and_stays_frozen(self):
        student=self.backend();teacher=self.backend()
        teacher.model.eval().requires_grad_(False)
        with torch.no_grad():teacher.model.model.early_exit_gate.bias.fill_(100.)
        algorithm=load_config(ROOT/'configs/hf_adaptive.json')['algorithm']
        objective=DistillationObjective(student,teacher,algorithm,2,True)
        loss,info=objective(torch.tensor([[1,20,30,40,50,2]]),3,[1,1,1])
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertEqual(info['target_depth_hist'].tolist(),[3,0,0,0])
        self.assertEqual(info['teacher_executed_token_loops'],5)
        self.assertIsNone(info['teacher_executed_loops'])
        self.assertTrue(all(parameter.grad is None for parameter in teacher.model.parameters()))

    def test_fixed_objective_has_n_targets_and_no_stop_bce(self):
        student=self.backend();teacher=self.backend()
        teacher.model.eval().requires_grad_(False)
        algorithm=load_config(ROOT/'configs/vllm_fixed_uniform.json')['algorithm']
        objective=DistillationObjective(student,teacher,algorithm,2,True)
        loss,info=objective(torch.tensor([[1,20,30,40,50,2]]),3,[2,2,2])
        loss.backward()
        self.assertEqual(info['stage_hist'].tolist(),[0,0,3])
        self.assertEqual(info['mapping_hist'].tolist(),[[0,3,0,0],[0,0,0,3]])
        self.assertEqual(float(info['stop_loss']),0.)
        self.assertIsNone(student.model.model.early_exit_gate.weight.grad)
        self.assertTrue(all(parameter.grad is None for parameter in teacher.model.parameters()))

    def test_fixed_rollout_actor_really_receives_student_n_not_teacher_k(self):
        from ep_loop.fastpath.rollout import RolloutBatcher
        captures=[]
        class Actor:
            def __init__(self,*args,**kwargs):self.loops=kwargs['loops'];captures.append(kwargs)
            def request(self,op,**kwargs):return {'weight_version':kwargs['version']} if op=='weights' else None
            def generate(self,requests,**kwargs):
                return dict(seconds=.1,executed_loops=self.loops,responses=[dict(token_ids=[40,2],exit_depths=[self.loops]*2,
                    executed_token_loops=self.loops*(len(row['input_ids'])+1)) for row in requests])
            def close(self):pass
        class Observer:
            def stage(self,*args,**kwargs):return nullcontext()
            def event(self,*args,**kwargs):pass
        config=load_config(ROOT/'configs/vllm_fixed_top_n.json')
        config['rollout']['responses_per_prompt']=1
        with tempfile.TemporaryDirectory() as folder,patch('ep_loop.fastpath.rollout.VllmActor',Actor),patch('torch.cuda.empty_cache'):
            batcher=RolloutBatcher(self.backend(),config,folder,0,Observer())
            batcher.prepare([dict(id='x',input_ids=[1,20,30])],[0],0,1,0,torch.Generator().manual_seed(42))
            response=batcher.pop(dict(id='x',sample=0))
            self.assertEqual(captures[0]['loops'],2)
            self.assertEqual(captures[0]['policy'],'fixed')
            self.assertEqual(response.execution_depths,[2,2])
            self.assertEqual(response.cache_policy,'vllm_fixed_depth')
            self.assertFalse(list(Path(folder).glob('.vllm_weights*')))

    def test_hybrid_evaluates_one_checkpoint_at_all_fixed_budgets(self):
        from scripts.evaluate_fastpath import main
        captures=[]
        class Actor:
            def __init__(self,directory,gpu,log,**kwargs):
                self.loops=kwargs['loops'];captures.append((str(directory),kwargs['loops'],kwargs['policy']))
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def generate(self,requests,**kwargs):
                return dict(seconds=.1,responses=[dict(token_ids=[2],exit_depths=[self.loops],finish_reason='stop',
                    executed_token_loops=self.loops*len(row['input_ids'])) for row in requests])
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);data=root/'data.jsonl';output=root/'result.jsonl'
            data.write_text(''.join(json.dumps(dict(id=str(i),problem='1+1?',answer='2'))+'\n' for i in range(2)))
            args=['evaluate_fastpath.py','--config',str(ROOT/'configs/hybrid.json'),'--checkpoint',directory,
                  '--data',str(data),'--output',str(output),'--gpus','2,3','--samples-per-problem','1']
            with patch('sys.argv',args),patch('transformers.AutoTokenizer.from_pretrained',return_value=ByteTokenizer()),\
                    patch('ep_loop.fastpath.actor.VllmActor',Actor):
                main()
            results=[json.loads(line) for line in output.read_text().splitlines()]
            self.assertEqual(len(results),8)
            self.assertEqual({row['max_loops'] for row in results},{1,2,3,4})
            self.assertTrue(all(row['policy']=='fixed' and row['actual_execution_depths']==[row['max_loops']] for row in results))
            self.assertEqual({row[0] for row in captures},{directory})
            self.assertTrue(all(row[2]=='fixed' for row in captures))

    def test_vllm_actor_does_not_inherit_incompatible_hf_allocator(self):
        from ep_loop.fastpath.actor import VllmActor
        process=MagicMock()
        process.stdout=iter(['{"ready":true}\n'])
        process.poll.return_value=0
        with tempfile.TemporaryDirectory() as directory,patch.dict(os.environ,
                {'PYTORCH_CUDA_ALLOC_CONF':'expandable_segments:True','RANK':'1','WORLD_SIZE':'2'}),\
                patch('subprocess.Popen',return_value=process) as spawn:
            actor=VllmActor('unused','3',Path(directory)/'actor.log',loops=2,policy='fixed',sleep=True)
            child=spawn.call_args.kwargs['env']
            self.assertNotIn('PYTORCH_CUDA_ALLOC_CONF',child)
            self.assertNotIn('RANK',child)
            self.assertEqual(child['CUDA_VISIBLE_DEVICES'],'3')
            self.assertEqual(os.environ['PYTORCH_CUDA_ALLOC_CONF'],'expandable_segments:True')
            actor.close()

    def test_route_configs_validate_without_teacher_distribution_approximation(self):
        for name in ['hf_adaptive','hybrid','vllm_fixed_top_n','vllm_fixed_uniform','vllm_fixed_endpoint']:
            config=validate_config(load_config(ROOT/'configs'/f'{name}.json'))
            self.assertEqual(config['algorithm']['teacher_distribution'],'full_vocab')
            self.assertIsNone(config['algorithm']['teacher_top_k'])


if __name__=='__main__':unittest.main()
